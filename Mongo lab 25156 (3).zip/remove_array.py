import json

# Load the original JSON file
with open('Country.json', 'r') as f:
    data = json.load(f)

# Flatten the data by iterating through all inner arrays and collecting their items
flattened_data = []
for inner_array in data:
    for item in inner_array:
        flattened_data.append(item)

# Save the flattened data to a new file
with open('1_processed_Country.json', 'w') as f:
    for item in flattened_data:
        json.dump(item, f)
        f.write('\n')
