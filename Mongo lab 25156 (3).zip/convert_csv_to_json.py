import pandas as pd
import json
import jsonschema
from jsonschema import validate

# Function to convert CSV to JSON in chunks and write directly to file
def csv_to_json(csv_file, json_file, chunk_size=100000):
    print(f"Converting {csv_file} to JSON...")
    
    # Open the JSON file for writing
    with open(json_file, 'w') as f:
        # Write an opening bracket for the JSON array
        f.write('[')
        
        # Read and process the CSV in chunks
        first_chunk = True
        for chunk in pd.read_csv(csv_file, chunksize=chunk_size):
            # Convert each chunk to a dictionary
            chunk_dict = chunk.to_dict(orient='records')
            
            # Write the chunk data to the JSON file
            if not first_chunk:
                f.write(',\n')  # Add a comma to separate the chunks
            else:
                first_chunk = False  # Only on the first chunk, avoid adding a leading comma
            
            # Write the chunk to the file as a JSON array
            json.dump(chunk_dict, f, indent=4)
        
        # Write the closing bracket for the JSON array
        f.write(']')
    
    print(f"Conversion complete. Data saved to {json_file}")

# Function to generate JSON Schema in chunks
def generate_json_schema(csv_file, schema_file, chunk_size=100000):
    print(f"Generating JSON Schema for {csv_file}...")
    
    # Initialize the schema components
    properties = {}
    
    # Read the CSV in chunks
    for chunk in pd.read_csv(csv_file, chunksize=chunk_size):
        # Process each chunk to determine column types
        for col in chunk.columns:
            if col not in properties:
                dtype = str(chunk[col].dtype)
                if 'int' in dtype:
                    properties[col] = {"type": "integer"}
                elif 'float' in dtype:
                    properties[col] = {"type": "number"}
                else:
                    properties[col] = {"type": "string"}

    # Generate the full JSON schema
    schema = {
        "type": "object",
        "properties": properties,
        "required": list(properties.keys())  # All columns are required
    }

    # Write the schema to a file
    with open(schema_file, 'w') as f:
        json.dump(schema, f, indent=4)

    print(f"JSON Schema generated and saved to {schema_file}")

# Convert both CSV files to JSON and generate JSON Schemas
csv_files = ['Indicators.csv', 'Series.csv', 'Country.csv']
json_files = ['Indicators.json', 'Series.json', 'Country.json']
schema_files = ['Indicators_schema.json', 'Series_schema.json', 'Country_schema.json']

# Process the files
for csv_file, json_file, schema_file in zip(csv_files, json_files, schema_files):
    
    # Convert CSV to JSON
    csv_to_json(csv_file, json_file, chunk_size=100000)
    
    # Generate JSON Schema
    generate_json_schema(csv_file, schema_file, chunk_size=100000)

    print(f"Finished processing {csv_file}\n")

print("All files processed successfully!")
