import org.apache.spark.streaming._
import org.apache.spark.SparkConf

object StreamWordCount {
  def main(args: Array[String]): Unit = {  // Fix the method signature
    // Step 1: Create SparkConf and StreamingContext
    val conf = new SparkConf().setAppName("StreamWordCount").setMaster("local[*]")
    val ssc = new StreamingContext(conf, Seconds(1))  // Batch interval of 1 second
    
    // Step 2: Create a DStream from the socket (listening on localhost:9000)
    val lines = ssc.socketTextStream("localhost", 9000)
    
    // Step 3: Define Processing Logic - Split the lines into words and count them
    val words = lines.flatMap(_.split(" "))  // Split each line into words
    val wordCounts = words.map(word => (word, 1)).reduceByKey(_ + _)  // Count each word
    
    // Step 4: Print the word counts to the console
    wordCounts.print()
    
    // Step 5: Start the StreamingContext
    ssc.start()  // Start processing the stream
    
    // Step 6: Await termination - keeps the stream running
    ssc.awaitTermination()
  }
}
